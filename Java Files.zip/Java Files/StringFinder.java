public class StringFinder {
  public static boolean findImperative(List<String> strings, String string) {
    boolean found = false;

    for (String str : strings) {
      if (str.equals(string)) {
        found = true;
        break;
      }
    }

    return found;
  }

  public static boolean findDeclarative(List<String> strings, String string) {
    return strings.contains(string);
  }
}