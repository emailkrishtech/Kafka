public class SimpleClass {
	public void method(String str){
		System.out.println("String method " + str);
	}
	public void method(Object object) {
		System.out.println("Object method " + object);
	}
	public static void main(String[] args) {
		SimpleClass instance = new SimpleClass();
		instance.method("Hello");
		instance.method(new String("World"));
		String str = new String("Mango");
		instance.method((Object)str);
		instance.method(null);
	}
}

output:
Object method Hello // String literal
String method World // String object
Object method Mango // upward casting
Object method null // null



Write program to return word as a list value and its length as a key in descending sorting order from below sentence, -
Input => 

String statement = "Hello World My name is Jane and I hate Mango Fruit ";

Output=>

{5 = [“Hello”, “World”, “Mango”, “Fruit”], 4 = [“name”, “Jane”, “hate”], 3 = [“and”], 2 = [“My”, “is”], 1 = [“I”]}