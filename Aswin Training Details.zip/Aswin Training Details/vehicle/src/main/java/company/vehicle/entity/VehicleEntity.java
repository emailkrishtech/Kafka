package company.vehicle.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
@Table(name="users")
public class VehicleEntity {

@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int id;
private String name;
private String type;
private int cost;

public VehicleEntity() {
	super();
}
public VehicleEntity(String name, String type, int cost) {
	super();
	this.name = name;
	this.type = type;
	this.cost = cost;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public int getCost() {
	return cost;
}
public void setCost(int cost) {
	this.cost = cost;
}
@Override
public String toString() {
	return "VehicleEntity [id=" + id + ", name=" + name + ", type=" + type + ", cost=" + cost + "]";
}


}
