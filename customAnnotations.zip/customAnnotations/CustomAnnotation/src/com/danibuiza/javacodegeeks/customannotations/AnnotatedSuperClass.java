package com.danibuiza.javacodegeeks.customannotations;

@InheritedAnnotation
public class AnnotatedSuperClass
{

    public void oneMethod()
    {

    }

}
