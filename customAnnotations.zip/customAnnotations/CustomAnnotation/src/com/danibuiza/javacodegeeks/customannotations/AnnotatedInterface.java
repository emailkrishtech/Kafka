package com.danibuiza.javacodegeeks.customannotations;

@InheritedAnnotation
public interface AnnotatedInterface
{

    public void oneMethod();

}
